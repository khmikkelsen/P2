package p2.communication;

public interface Tester<E>
{
    boolean test(E e);
}
